import ready from './utilities/ready';
import initApp from './app';

ready (() => {
  initApp ();
});
